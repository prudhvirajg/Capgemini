package com.cg.inheritance.app;
import java.util.Date;

import javax.persistence.*;

import com.cg.inheritance.entities.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
EntityManagerFactory fact=Persistence.createEntityManagerFactory("JPA-PU");
EntityManager em=fact.createEntityManager();

LifeInsurance policy1=new LifeInsurance();
CarInsurance policy2=new CarInsurance();


policy1.setPolicyId(10023);
policy1.setDateOfIssue(new Date());
policy1.setSumAssured(2300000D);
policy1.setInsuredPersonName("narendra");
policy1.setInsuredPersonAge(50);

policy2.setPolicyId(20003);
policy2.setDateOfIssue(new Date());
policy2.setSumAssured(5000000D);
policy2.setCarModel("Lamborghini");
policy2.setChassisNumber("5425145345345");


EntityTransaction tn=em.getTransaction();
tn.begin();
em.persist(policy1);
em.persist(policy2);
tn.commit();
System.out.println("Saved..!!");

em.close();
fact.close();



	}

}
