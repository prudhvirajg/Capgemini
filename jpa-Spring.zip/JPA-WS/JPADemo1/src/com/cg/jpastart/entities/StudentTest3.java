package com.cg.jpastart.entities;
           
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
            
public class StudentTest3 {
           
	public static void main(String[] args) {
		   
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	//create connection to data base
		EntityManager em = factory.createEntityManager();
		//studetn does not exists! (Stage 0)
        em.getTransaction().begin();
        //new student [stage 1]
        Student student=new Student();
        student.setStudentId(203);
        student.setName("jerry");
        //managed [stage 2]
        em.persist(student);
        
        //any change in object when its in managed state
        //results in update query fired by JPA
        //condition must be invoked before "commit"
        student.setName("bhopal");
        em.getTransaction().commit();
        System.out.println("one student added to database");
        //close the connection 
		em.close();
		//detached
		factory.close();
	}      
}          
