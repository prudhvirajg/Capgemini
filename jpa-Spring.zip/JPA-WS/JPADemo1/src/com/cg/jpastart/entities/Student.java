package com.cg.jpastart.entities;
import java.io.Serializable;

import javax.persistence.*;
@Entity
@Table(name="student")
public class Student implements Serializable {

	@Id
//	@GeneratedValue(strategy=GenerationType.AUTO)
	private int studentId;
	private String name;
	//Every time a new Student is created,
		//Create Address as well!
		@OneToOne(cascade=CascadeType.PERSIST)
		//Reference to FORIENG KEY
		@JoinColumn(name="address_id")
		private Address address;

	

}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	
	

}
