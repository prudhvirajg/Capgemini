package com.cg.manytomany.entities;
import javax.persistence.*;
import java.io.Serializable;

import java.util.Date;
import java.util.Set;
@Entity
@Table(name="order_master")
public class Order implements Serializable{
@Id private Integer id;
@Column(name="order_date")
@Temporal(TemporalType.DATE)
private Date orderDate;

//map join table(joinTable is table used for cross referencing,no seperate entity is created for it)
@ManyToMany
@JoinTable(name="product_orders",joinColumns= {@JoinColumn(name="order_id")},
             inverseJoinColumns= {@JoinColumn(name="product_id")})
private Set<Product> products;

public Integer getId() {
	return id;
}

public void setId(Integer id) {
	this.id = id;
}

public Date getOrderDate() {
	return orderDate;
}

public void setOrderDate(Date orderDate) {
	this.orderDate = orderDate;
}

public Set<Product> getProducts() {
	return products;
}

public void setProducts(Set<Product> products) {
	this.products = products;
}




}
