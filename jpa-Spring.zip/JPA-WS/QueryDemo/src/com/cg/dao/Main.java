package com.cg.dao;


import java.util.*;
import com.cg.entities.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BookDAO dao= new BookDaoImpl();
		
		System.out.println("Test find by ID");
		Book book = dao.getBookById(102);
		System.out.println("Book found: "+book.getTitle());
		
		
		System.out.println("Test find by author");
		List<Book> books =dao.getBookByAuthor(" Java for Android, Second Edition");
		System.out.println("Book found from author"+books.get(0).getAuthor());
		
		
		System.out.println("Test find by title");
		List<Book> book1 =dao.getBookByTitle("Java for Android, Second Edition");
		System.out.println("Book found from title"+book1.get(0).getTitle());
		
		System.out.println("Test find by title");
		List<Book> book2 =dao.getBooksInpriceRange(340, 700);
		System.out.println("Book found by price "+book2.get(0).getTitle());
	}

}
