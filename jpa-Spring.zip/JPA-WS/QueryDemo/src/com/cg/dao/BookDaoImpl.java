package com.cg.dao;

import java.util.List;
import javax.persistence.*;
import com.cg.entities.Book;


public class BookDaoImpl implements BookDAO {

 private EntityManager em=JPAUtil.getEntityManager();

 @Override
 public Book getBookById(int id) {
	 return em.find(Book.class, id);
 }



 @Override
 public List<Book> getBookByTitle(String title) {
 Query q=em.createQuery("select b from Book b "
		 +"where lower(b.title) like lower(:title)");
 q.setParameter("title", "%"+title+"%");
 return q.getResultList();
 }

 @Override
 public List<Book> getBookByAuthor(String author) {
 Query q=em.createQuery("select b from Book b where b.author=:author");
 q.setParameter("author", author.trim());
 return q.getResultList();

 }



 @Override
 public Long countBooks(){
 Query q=em.createQuery("select count(b) from Book b ");
 return (Long) q.getSingleResult();

 }
 @Override
 public List<Book> getAllBooks() {
 Query q = em.createQuery("getAllBooks");
 return q.getResultList();
 }



 @Override
 public List<Book> getBooksInpriceRange(float min, float max) {
 TypedQuery<Book> q = (TypedQuery<Book>) em.createQuery
		 ("select b from Book b where b.price between :min and : max");
 q.setParameter("min", min);
 q.setParameter("max", max);
 return q.getResultList();

 }







}

