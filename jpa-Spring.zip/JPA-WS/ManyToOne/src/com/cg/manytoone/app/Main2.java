package com.cg.manytoone.app;

import java.util.*;

import javax.persistence.*;
import com.cg.manytoone.entities.*;
public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		EntityManagerFactory fact=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=fact.createEntityManager();
		
		//jpql query to seach all employees working ni department #202
		/*TypedQuery<Employee> q=em.createQuery("select e from employee e where e.department.id= :id"
				,Employee.class);
		q.setParameter("id", 202);
		List<Employee> emps=q.getResultList();*/
		
		Department d=em.find(Department.class, 202);
		Set<Employee> emps=d.getEmployees();
		System.out.println("found records :"+emps.size());
		for(Employee e:emps) {
			System.out.println(e.getId()+" "+e.getName());
		}
		em.close();
		fact.close();
		
		
	}
}
