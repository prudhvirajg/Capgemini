package com.cg.manytoone.app;
import javax.persistence.*;
import com.cg.manytoone.entities.*;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
EntityManagerFactory fact=Persistence.createEntityManagerFactory("JPA-PU");
EntityManager em=fact.createEntityManager();
Department dept=new Department();
dept.setId(202);
dept.setName("Avengers");

Employee emp=new Employee();
emp.setId(101);
emp.setName("Chris Evans");
emp.setDepartment(dept);

Employee emp1=new Employee();
emp1.setId(102);
emp1.setName("Robert Downey jr.");
emp1.setDepartment(dept);

Employee emp2=new Employee();
emp2.setId(103);
emp2.setName("Bruce Wayne");
emp2.setDepartment(dept);

EntityTransaction tn=em.getTransaction();
tn.begin();
em.persist(dept);
em.persist(emp);
em.persist(emp1);
em.persist(emp2);
tn.commit();
em.close();
fact.close();
}
}
