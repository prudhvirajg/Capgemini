package com.cg.onetoone.entities;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="student")
public class Student implements Serializable{
@Id
private Integer StudentId;
private String name;

//Every time a new Student is created,
//Create Address as well!
@OneToOne(cascade=CascadeType.PERSIST)
//Reference to FORIENG KEY
@JoinColumn(name="address_id")
private Address address;


public Integer getStudentId() {
	return StudentId;
}
public void setStudentId(Integer studentId) {
	StudentId = studentId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Address getAddress() {
	return address;
}
public void setAddress(Address address) {
	this.address = address;
}



}
