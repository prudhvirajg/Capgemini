import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
loginForm:FormGroup;
submitted:boolean=false;
invalidLogin:boolean=false;
  constructor(private formBuilder:FormBuilder,private router:Router) { }
onSubmit(){
  this.submitted=true;
  if(this.loginForm.invalid){
    return;
  }
 // let password=this.loginForm.controls.password.value;
  let username=this.loginForm.controls.email.value;
  if(this.loginForm.controls.email.value=="hulk@avengers.com" && this.loginForm.controls.password.value == "123456")
  {
    localStorage.setItem("username",username);
    //localStorage.setItem("password",password);
    this.router.navigate(['list-user']); 
  }
 
  else{
    
    this.invalidLogin=true;
  }
}
  ngOnInit() {
    this.loginForm=this.formBuilder.group({
      email:['',Validators.required],
      password:['',Validators.required]
    });
  }

}
