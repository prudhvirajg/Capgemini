import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router, ActivatedRoute } from '../../../node_modules/@angular/router';
import { UserService } from '../services/user.service';
import { VALID } from '../../../node_modules/@angular/forms/src/model';


@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.css']
})
export class EditUserComponent implements OnInit {
  editForm: FormGroup;
  submitted: boolean = false;
  userId:string;
  numPattern="[6-9]{1}[0-9]{9}";
  constructor(private formBuilder: FormBuilder, private router: Router,
                     private route:ActivatedRoute,private userService:UserService ) {
                       this.route.params.subscribe
                       (params=>this.userId=params['id']);
                       console.log(this.userId);
                      }
  
  logOutUser():void{
    if(localStorage.getItem("username")!=null){
     localStorage.removeItem("username");
     this.router.navigate(['/login']);
    }
 }
  ngOnInit() {
    // if(localStorage.getItem("username")!=null){
    //   let userId=localStorage.getItem("editUserId");
      if(this.userId!=null){
        if(!this.userId){
        alert('invalid action');
        this.router.navigate(['list-user']);
        return;
      
    }
    this.editForm = this.formBuilder.group({
      id:[],
      firstName:['',Validators.required],
      lastName:['',Validators.required],
      email:['',Validators.required],
      contactDetails:['',[Validators.required,Validators.pattern(this.numPattern)]],
      age:['',[Validators.required,Validators.min(15),Validators.max(50)]]
    });
    this.userService.getUserById(+this.userId)
    .subscribe(data=>{
      this.editForm.setValue(data)
    });
  }
  else{
    this.router.navigate(['/login']);
  }
}
onSubmit(){
  this.submitted=true;
  if(this.editForm.invalid){
    return;
  }
  console.log(this.editForm.value);
  this.userService.updateUser(this.editForm.value) 
  .subscribe(data=>{
    alert(this.editForm.controls.firstName.value+' recors edited successfully..!!');
    this.router.navigate(['list-user'])
  })
}

}
