import { Component, OnInit } from '@angular/core';
import { MathService } from '../services/math.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
title:string="welcome to angular 6"
  result:number;
  resul:number;
  a:number=5;
  b:number=6;
//dependancy injection
constructor(private mathService:MathService){}
 

  ngOnInit() {
 this.resul=this.mathService.addition(this.a,this.b);
 console.log("addition is" +this.resul);

 this.result=this.mathService.multiplication(this.a,this.b);
 console.log("multiplication is" +this.result);


  }

}
