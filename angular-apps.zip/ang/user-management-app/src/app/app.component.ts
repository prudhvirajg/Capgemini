import { Component } from '@angular/core';

/*
'[app-root]' --> attribute
'.app-root'--> matches class
'app-root' --> matches element
*/
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  // template:`<h1>welcome to my app</h1>
  // <hr/>
  // <h2>root component</h2>`,

  styleUrls: ['./app.component.css'],
  
})
export class AppComponent {
  title = 'zombie world';
  developer ='the_dead'
  a=10;
  b=20;
  todaysDate=new Date();
}
