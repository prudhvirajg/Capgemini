import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ShowNameComponent } from './show-name/show-name.component';
import { ChangeStyleDirective } from './directives/change-style.directive';

@NgModule({
  //all user defined components ,directives and pipes must be registred in declarations section
  declarations: [
    AppComponent,
    ShowNameComponent,
    ChangeStyleDirective
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
