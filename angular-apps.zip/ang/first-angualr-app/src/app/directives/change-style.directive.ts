import { Directive, ElementRef } from '@angular/core';


@Directive({
  selector: '[AppChangeStyle]'
})
export class ChangeStyleDirective {

  //inject elementRef class inside the constructor  
  //constructor injection elementref is built in class which points to HtmlElement like div,h1,p,etc
  constructor(Element:ElementRef) {
    console.log(Element);
    Element.nativeElement.innerHTML=`
    <marquee scrollamount="10"> <i>welcome to directive </i>
    </marquee>`;
   }

}
