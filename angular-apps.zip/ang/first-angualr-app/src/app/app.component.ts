import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'first-angular-app';
  public name="cersei";
  public address="westeros";
  public message="";
  //cust object -java Script Object
  //json data
  cust={
    name:'brandon Stark',
    age:25,
    address:{
      city:'Winterfell',
      state:'North'
    }
  };
}
