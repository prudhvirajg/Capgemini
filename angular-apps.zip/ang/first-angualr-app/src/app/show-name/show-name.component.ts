import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-show-name',
  //templateUrl: './show-name.component.html',
  template:`  <h2>{{"Hey "+name+" from  "+address}}</h2> 
               <button (click)="received()">
                send notification</button> `, 
styleUrls: ['./show-name.component.css']
})
export class ShowNameComponent implements OnInit {
    //sending data parent to child
 @Input("parentData") public name;
 @Input("parentAdd") public address;
 //sending data from child to parent 
 @Output("") public nameReceivedEvent = new EventEmitter();
  constructor() { }

  ngOnInit() {
  }
received(){
  this.nameReceivedEvent.emit("Name recived ...!!");
}
}
