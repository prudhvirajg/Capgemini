import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Card } from '../model/cards.model';

@Injectable({
  providedIn: 'root'
})
export class CardsService {
constructor(private http:HttpClient) { }
baseUrl:string='http://localhost:8080/card/create';
createCard(card:Card){
  return this.http.post(this.baseUrl,card);
}

}
