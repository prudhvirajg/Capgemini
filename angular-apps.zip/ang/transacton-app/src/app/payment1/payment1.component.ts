import { Component, OnInit } from '@angular/core';


import { CardsService } from '../services/cards.service';
import { Router } from '../../../node_modules/@angular/router';
import { FormBuilder, FormGroup, Validators } from '../../../node_modules/@angular/forms';


@Component({
  selector: 'app-payment1',
  templateUrl: './payment1.component.html',
  styleUrls: ['./payment1.component.css']
})
export class Payment1Component implements OnInit {
  addForm: FormGroup;
  submitted: boolean = false;
  numPattern="[0-9]{16}";
  cvvpattern="[1-9]{3}";
  datepattern="[0-9]{2}[/][0-9]{2}";
  namepattern="[a-z,A-Z]{3,}";
  constructor(private formBuilder: FormBuilder, private router: Router,private cardService:CardsService) { }
    onSubmit(){
      this.submitted=true;
      if(this.addForm.invalid){
        return;
      }
      console.log(this.addForm.value);
      this.cardService.createCard(this.addForm.value) 
      .subscribe(data=>{
        alert(this.addForm.controls.cname.value+' recors added successfully..!!');
       // this.router.navigate(['list-user'])
      })
    }
  

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      cardno:['',[Validators.required,Validators.pattern(this.numPattern)]],
      expdate:['',[Validators.required,Validators.pattern(this.datepattern)]],
      cvv:['',[Validators.required,Validators.pattern(this.cvvpattern)]],
      cname:['',[Validators.required,Validators.pattern(this.namepattern)]],
      
    });
  }
}