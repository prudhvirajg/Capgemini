export class Card{
    cardno:number;
    expdate:string;
    cvv:number;
    cname:string;
}