import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { Payment1Component } from './payment1/payment1.component';

const routes: Routes = [
 
  {path:'payment1',component:Payment1Component}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
