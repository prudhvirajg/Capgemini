import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { ListUserComponent } from './list-user/list-user.component';
import { HttpClientModule } from '../../node_modules/@angular/common/http';

@NgModule({
  //all user defined components,directives,pipes
  declarations: [
    AppComponent,

    HomeComponent,

    LoginComponent,

    AddUserComponent,

    EditUserComponent,

    ListUserComponent
  ],
  // all user defined and pre defined modules
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule
  ],//all user defined services
  providers: [],
  //kick starting the application[main/root component name]
  bootstrap: [AppComponent]
})
export class AppModule { }
