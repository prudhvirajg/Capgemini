export class Product{
    id:number;
    productName:string;
    productPrice:number;
    productQuantity:number;
}