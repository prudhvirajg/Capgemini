import { Component } from '@angular/core';
import { SignUpService } from '../services/signup.service';
import { FormBuilder, FormGroup, Validators } from '../../node_modules/@angular/forms';
import { Router } from '../../node_modules/@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'sign-up-app';
  addForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router,private signupService:SignUpService) { }
    onSubmit(){
      this.submitted=true;
      if(this.addForm.invalid){
        return;
      }
      console.log(this.addForm.value);
      this.signupService.createCard(this.addForm.value) 
      .subscribe(data=>{
        alert(this.addForm.controls.cname.value+' recors added successfully..!!');
       // this.router.navigate(['list-user'])
      })
    }
  

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      cname:['',Validators.required],
      email:['',Validators.required],
      password:['',Validators.required],
      customer:['',Validators.required]
    });
  }
}
