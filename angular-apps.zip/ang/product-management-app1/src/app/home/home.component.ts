import { Component, OnInit } from '@angular/core';
// import {MathService} from '../services/math.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
title:string="welcome to angular 6";


  result: number;
  result1: number;
  a: number = 10;
  b: number = 20;
  //Dependency injection
  constructor(){}

  ngOnInit() {
// this.result = this.mathService.addition(this.a,this.b);
// console.log("Addition is: " +this.result);

// this.result1 = this.mathService.multiplication(this.a,this.b);
// console.log("Multiplication  is: "+this.result1);


  }

}
