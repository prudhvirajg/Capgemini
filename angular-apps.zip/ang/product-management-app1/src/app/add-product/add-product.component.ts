import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router } from '../../../node_modules/@angular/router';
import { ProductService } from '../services/product.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  addForm: FormGroup;
  submitted: boolean = false;

  constructor(private formBuilder: FormBuilder,private router:Router,private productService: ProductService) { }

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id: [],
      productname: ['', Validators.required],
      price: ['', [Validators.required,Validators.min(1)]],
      quantity: ['',[Validators.required],[Validators.min(1)]]
    });
  }

  //onSubmit() function
  onSubmit(){
    this.submitted =true;
    if(this.addForm.invalid){
      return;
    }
    console.log(this.addForm.value);

    this.productService.createProduct(this.addForm.value).subscribe(data=>{
      alert(this.addForm.controls.productname.value + ' record is added successfully..');
      this.router.navigate(['list-product']);
    })
  }

}