import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { Router } from '../../../node_modules/@angular/router';
import { ProductService } from '../services/product.service';
import { Product } from '../model/product.model';

@Component({
  selector: 'app-edit-product',
  templateUrl: './edit-product.component.html',
  styleUrls: ['./edit-product.component.css']
})

export class EditProductComponent implements OnInit {

  editForm: FormGroup;
  submitted: boolean = false;
  product: Product;

  constructor(private formBuilder: FormBuilder,private router:Router,private productService: ProductService) { }

  //Logoff user
  // logOutUser():void{
  //   if(localStorage.getItem("username")!=null){  //get username from browser->F12->Application->Local Storage
  //     localStorage.removeItem("username");
  //     this.router.navigate(['/login']);
  //   }
  // }

  ngOnInit() {
    //if(localStorage.getItem("username")!=null){
      let productId = localStorage.getItem("editProductId");
      if(!productId){
        alert('Invalid action');
        this.router.navigate(['list-product']);
        return;
      }
    this.editForm = this.formBuilder.group({
      id: [],
      productname: ['', Validators.required],
      price: ['', [Validators.required,Validators.min(1)]],
      quantity:['',Validators.required],
    });
    //pulling data from database using service
  this.productService.getProductById(+productId)  //+ passing the userId
    .subscribe(data=>{
      this.editForm.setValue(data)
    });
  // }
  // else{
  //   this.router.navigate(['/list']);
  // }
  }
  
  //onSubmit() function
  onSubmit(){
    this.submitted =true;
    if(this.editForm.invalid){
      return;
    }
    console.log(this.editForm.value);

    this.productService.updateProduct(this.editForm.value).subscribe(data=>{
      alert(this.editForm.controls.productname.value+ ' record is edited successfully..');
      this.router.navigate(['/list-product']);
    })
  }
}
