import { Component, OnInit } from '@angular/core';
import { Product } from '../model/product.model';
import { Router } from '../../../node_modules/@angular/router';
import { ProductService } from '../services/product.service';


@Component({
  selector: 'app-list-product',
  templateUrl: './list-product.component.html',
  styleUrls: ['./list-product.component.css']
})
export class ListProductComponent implements OnInit {
  //creating an array of User class
  products: Product[];

  //Constructor Dependency
  constructor(private router:Router, private productService:ProductService) { }

  //loading all users as soon as component is loaded
  ngOnInit() {
    //if(localStorage.getItem("productname")!=null)
  {

this.productService.getProducts()
.subscribe(data=>{      //subscribe method observes all the changes and update teh changes
  this.products =data;
   });
}
// else{
//   this.router.navigate(['/list-product']);
//  }
}
  //logOff user
// logOutUser():void{
//   if(localStorage.getItem("username")!=null){  //get username from browser->F12->Application->Local Storage
//     localStorage.removeItem("username");
//     this.router.navigate(['/list-product']);
//   }
// }

//Delete user
deleteProduct(product: Product):void{
  let result = confirm("Do you want to delete the product?")
  if(result){
    this.productService.deleteProduct(product.id)
    .subscribe(data=>{
      this.products = this.products.filter(u=> u!==product);
    })
  }
}

//Modify user
editProduct(product:Product):void{
  localStorage.removeItem("editProductId");
  localStorage.setItem("editProductId",product.id.toString());
  this.router.navigate(['edit-product']);
}

//Add User
addProduct():void{
  this.router.navigate(['add-product']);
}

}
