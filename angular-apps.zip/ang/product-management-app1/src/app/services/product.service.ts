import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from '../model/product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http:HttpClient) { }
  baseUrl:string = 'http://localhost:3000/products';
 
  //get users
  getProducts()
  {
    return this.http.get<Product[]>(this.baseUrl);
  }

  //get users by id
  getProductById(id: number){
    return this.http.get<Product>(this.baseUrl+'/'+id);
  }

  //Create User
  createProduct(product:Product)
  {
    return this.http.post(this.baseUrl,product);
  }

  //modify user
  updateProduct(product:Product)
  {
    return this.http.put(this.baseUrl + '/' + product.id,product);
  }

  //delete user
  deleteProduct(id: number)
  {
    return this.http.delete(this.baseUrl + '/' +id); 
  }
}
  