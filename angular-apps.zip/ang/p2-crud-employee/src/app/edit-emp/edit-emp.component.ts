import { Component, OnInit } from '@angular/core';
import { EmployeeService } from '../service/employee.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-edit-emp',
  templateUrl: './edit-emp.component.html',
  styleUrls: ['./edit-emp.component.css']
})
export class EditEmpComponent implements OnInit {
  empformlabel: string = 'Edit-Product';
  empformbtn: string = 'Update';
  constructor(private formBuilder: FormBuilder, private router: Router, private empService: EmployeeService) {
  }

  addForm: FormGroup;
  ngOnInit() {

    this.addForm = this.formBuilder.group({
      id: [],
      employee_name: ['', Validators.required],
      employee_salary: ['', [Validators.required, Validators.maxLength(9)]],
      employee_age: ['', [Validators.required, Validators.maxLength(3)]]
    });

    let empid = localStorage.getItem('editEmpId');
    if (+empid > 0) {
      this.empService.getEmployeeById(+empid).subscribe(data => {
        this.addForm.patchValue(data);
      })
      // this.empformlabel = 'Edit Employee';
      // this.empformbtn = 'Update';
    }
  }

  onUpdate() {
    console.log('Updating record.');
    this.empService.updateEmployee(this.addForm.value).subscribe(data => {
      alert("record updated");
      this.router.navigate(['list-product']);
    },
      error => {
        alert(error);
      });
  }
}
