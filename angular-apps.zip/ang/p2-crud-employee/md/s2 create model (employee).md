#create model folder inside app
[employee.model.ts]
export class Employee {
    id?: number;
    employee_name?: string;
    employee_salary?: number;
    employee_age?: number;
} 