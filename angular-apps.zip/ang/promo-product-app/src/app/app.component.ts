import { Component } from '@angular/core';


/*
[app-root] -> matches attributes
.app-root  -> matches class
<app-root> -> matches element 

*/
@Component({
  selector: 'app-root',
   templateUrl: './app.component.html',
  // template:`<h1> Welcome to My app</h1>
  // <hr />
  // <h2>This is Root component</h2>`
  
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title = 'A to Z solutions';
  developer="Pragadeesh";
  todaysDate= new Date();
}
