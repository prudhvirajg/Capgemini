import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DetailsComponent } from './details/details.component';
import { ProductComponent } from './product/product.component';
import { ListUserComponent } from './list-user/list-user.component';




const routes: Routes = [
 {path:'details',component:DetailsComponent},
  {path:'product',component:ProductComponent},
  {path:'list-user',component:ListUserComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
