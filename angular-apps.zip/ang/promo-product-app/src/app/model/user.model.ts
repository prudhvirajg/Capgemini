export class User {
    promocode: number;
    description: string;
    amount: number;
    date: string;
}
