export class Product {
    productid: number;
    productdetails: string;
    price: number;
}