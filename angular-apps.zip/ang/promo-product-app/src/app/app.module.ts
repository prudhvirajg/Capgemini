import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';

import { DetailsComponent } from './details/details.component';
import { ProductComponent } from './product/product.component';
import { ListUserComponent } from './list-user/list-user.component';



@NgModule({
  //all user defined components,directives, pipes
  declarations: [
    AppComponent,
    ListUserComponent,
    DetailsComponent,
    ProductComponent
  ],
  //all user defined and pre-defined modules

  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    FormsModule
  ],
  //all user defined services

  providers: [],

  // kick starting the application[Root component name]

  bootstrap: [AppComponent]
})
export class AppModule { }
