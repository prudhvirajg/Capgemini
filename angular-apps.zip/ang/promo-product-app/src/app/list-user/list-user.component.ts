import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.model';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';
@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {
  users: User[];
  public searchText: any;
  constructor(private router: Router, private userService: UserService) { }
  ngOnInit() {
    this.userService.getUsers()
      .subscribe(data => {
        this.users = data
      });
  }
  success() {
    alert("Sent Mail Successfully");
  }
}