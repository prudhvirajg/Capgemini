import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { User } from '../model/user.model';
import { Product } from '../model/product.model';
@Injectable({
  providedIn: 'root'
})
export class UserService {
 constructor(private http:HttpClient) { }
  baseUrl:string ='http://localhost:8080/store';
  getUsers(){
  return this.http.get<User[]>(this.baseUrl+'/getpromo');
  }
  getProducts(){
    return this.http.get<Product[]>(this.baseUrl+'/getproduct');
  }
}
