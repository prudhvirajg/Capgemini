package com.cg;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.java.*;
import cucumber.api.junit.Cucumber;
//run with cucumber test runner
@RunWith(Cucumber.class)
//dryRun:true to validate the steps and feature file
//dryRun:false to validate and then execute test cases
                        //(throws exception when steps re missing )
//features=  the package or directory which contains all feature files
//monochrome:true Disable extra formatting characters
             //and generate sample plain test output
//monochrome : false enable extra formatiing (for Linus OS Only)
                //do not use on windows 
@CucumberOptions(dryRun=false,features="classpath:/features",monochrome=true)
public class TestMain {

	
}
