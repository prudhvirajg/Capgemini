package com.cg.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class DetailsPage {
	private WebDriver driver = null;
	
	public DetailsPage(WebDriver driver) {
		super();
		this.driver = driver;
		//Register the Page Factory : Responsible to extract all web elements 
		PageFactory.initElements(driver, this);
		///////////////////////////
	}
	@FindBy(id="usrID")
	private WebElement userid;
	
	@FindBy(id="pwd")
	private WebElement password;
	
	
	@FindBy(id="usrname")
	private WebElement username;
	
	@FindBy(id="addr")
	private WebElement address;
	
	@FindBy(name="zip")
	private WebElement zipcode;
	
	@FindBy(name="email")
	private WebElement email;
	
	@FindBy(name="sex")
	private WebElement click;
	
	@FindBy(name="submit")
	private WebElement onclick;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserid() {
		return userid;
	}

	public void setUserid(WebElement userid) {
		this.userid=userid;
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(WebElement password) {
		this.password = password;
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(WebElement username) {
		this.username = username;
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(WebElement address) {
		this.address = address;
	}

	public WebElement getZipcode() {
		return zipcode;
	}

	public void setZipcode(WebElement zipcode) {
		this.zipcode = zipcode;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getClick() {
		return click;
	}

	public void setClick(WebElement click) {
		this.click = click;
	}

	public WebElement getOnclick() {
		return onclick;
	}

	public void setOnclick(WebElement onclick) {
		this.onclick = onclick;
	}
	
	
	
	
}
