package com.cg;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TransactionImplTest {
AccountManager am=new AccountManager();
TransactionImpl impl=new TransactionImpl(am);
	@Before
	public void setUp() throws Exception {
		System.out.println("sample data for testing");
		Map<Integer,Account> sample=new HashMap<>();
		sample.put(101, new Account(101,"Aladdin",50));
		sample.put(102, new Account(102,"Price Ali",5000000));
		sample.put(103, new Account(103,"Jasmine",250000));
		sample.put(104, new Account(104,"Genie",900000000));
		am.setAccounts(sample);
	}
	@After
	public void tearDown() throws Exception {
		am.setAccounts(new HashMap<>());
	}
	@Test
	public void testWithdraw() {
		impl.withdraw(103, 50000);
		assertEquals(200000,am.findByAccountNo(103).getBalance(),0.01D);
	}
	
	@Test
	public void testWithdraw2() {
		impl.withdraw(101, 0);
		assertEquals(50,am.findByAccountNo(101).getBalance(),0.01D);
	}
	@Test
	public void testDeposit() {
		impl.deposit(103,20000);
		assertEquals(270000,am.findByAccountNo(103).getBalance(),0.01D);
	}

}
