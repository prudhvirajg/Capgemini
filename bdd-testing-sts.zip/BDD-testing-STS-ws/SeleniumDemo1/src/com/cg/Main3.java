package com.cg;

import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\sel-jars\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		dr.get("file:///C:/HTML-Pages/PopupWin.html");
		String pa=dr.getWindowHandle().toString();
		System.out.println("parent window : "+pa);
		
		
		
		dr.findElement(By.name("Open")).click();
		try {
			Thread.sleep(10000);
		}catch(InterruptedException e){
			
		}
		
		Set<String> children=dr.getWindowHandles();
		System.out.println("the number of children windows are : "+children.size());
		
		for(String childWin:children) {
			if(childWin.equals(pa)) {
				continue;
			}
			System.out.println("child Window : "+childWin);
			dr.switchTo().window(childWin.toString());
			System.out.println(dr.getTitle());
		}
		dr.switchTo().window(pa);		
		dr.close();
	}
}
