package com.cg;

import org.openqa.selenium.htmlunit.HtmlUnitDriver;

public class HtmlUnitDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
HtmlUnitDriver d=new HtmlUnitDriver();
d.get("file:///C:/HTML-Pages/TestHTMLUnit.html");
System.out.println("title on page: "+d.getTitle());

d.close();
	}

}
