package com.cg;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver","C:\\sel-jars\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		dr.get("file:///C:/HTML-Pages/AlertExample.html");
		
		dr.findElement(By.name("btnAlert")).click();
		Alert a=dr.switchTo().alert();
		String text=a.getText();
		a.accept();
		System.out.println("Alert had text "+text);
		try {
			Thread.sleep(10000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		dr.close();
	}

}
