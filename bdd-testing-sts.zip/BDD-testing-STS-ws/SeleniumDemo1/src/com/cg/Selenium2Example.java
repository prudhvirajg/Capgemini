package com.cg;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Selenium2Example {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		System.setProperty("webdriver.chrome.driver","C:\\sel-jars\\chromedriver.exe");
		ChromeDriver dr=new ChromeDriver();
		dr.get("file:///C:/HTML-Pages/WorkingWithForms.html");
		WebElement el=dr.findElement(By.name("txtUName"));
		el.sendKeys("braavoo");
	
		WebElement el1=dr.findElement(By.name("txtPwd"));
		el1.sendKeys("raavan");
		
		WebElement el2=dr.findElement(By.id("txtConfPassword"));
		el2.sendKeys("raavan");
		
		
		WebElement el3=dr.findElement(By.id("txtFirstName"));
		el3.sendKeys("PRUDHVI RAJ");
		
		WebElement el4=dr.findElement(By.id("txtLastName"));
		el4.sendKeys("G");
		
		
		WebElement el5=dr.findElement(By.id("rbMale"));
		el5.click();
		
		WebElement el6=dr.findElement(By.id("txtEmail"));
		el6.sendKeys("pg@gmail.com");
		
		WebElement el7=dr.findElement(By.name("DtOB"));
		el7.sendKeys("20-Apr-1997");
		
		WebElement el8=dr.findElement(By.id("txtAddress"));
		el8.sendKeys("ongole");
		
		Select sel =new Select(dr.findElement(By.name("City")));
		sel.selectByIndex(2);
		
		
		WebElement el10=dr.findElement(By.id("txtPhone"));
		el10.sendKeys("9481740799");
		
		WebElement el9=dr.findElement(By.name("chkHobbies"));
		el9.click();
		try {
			Thread.sleep(10000);
		}catch(InterruptedException e){
			e.printStackTrace();
		}
		System.out.println("title: "+dr.getTitle());
		dr.quit();
	}

}
