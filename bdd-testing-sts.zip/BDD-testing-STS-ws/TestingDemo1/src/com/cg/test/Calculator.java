package com.cg.test;

public class Calculator {

	
	public double doSum(int x,int y){
		return x+y;
	}
	 public double doSub(int x,int y) {
		 return x-y;
	 }
	 public double doMult(int x,int y) {
		 return x*y;
	 }

public double doDiv(int x,int y) {
	 return x/y;
}
}