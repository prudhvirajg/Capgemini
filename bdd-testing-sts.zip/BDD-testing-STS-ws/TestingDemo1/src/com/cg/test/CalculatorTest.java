package com.cg.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class CalculatorTest {

	
	Calculator cal=new Calculator();
	
	@Test
	public void testDoSum() {
		double ans=cal.doSum(10,12);
		assertEquals(22,ans,0.01D);
	}
	@Test
	public void testDoSub() {
		double ans=cal.doSub(18,12);
		assertEquals(6,ans,0.01D);
	}
	@Test
	public void testDoMult() {
		double ans=cal.doMult(10,12);
		assertEquals(120,ans,0.01D);
	}
	@Test
	public void testDoDiv() {
		double ans=cal.doDiv(20,2);
		assertEquals(10,ans,0.01D);
	}


}

