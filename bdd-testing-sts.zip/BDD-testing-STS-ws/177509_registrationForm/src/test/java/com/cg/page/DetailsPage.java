package com.cg.page;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class DetailsPage {
	private WebDriver driver = null;
	
	public DetailsPage(WebDriver driver) {
		super();
		this.driver = driver;
		//Register the Page Factory : Responsible to extract all web elements 
		PageFactory.initElements(driver, this);
		///////////////////////////
	}
	@FindBy(id="usrID")
	private WebElement userid;
	
	@FindBy(id="pwd")
	private WebElement password;
	
	
	@FindBy(id="usrname")
	private WebElement username;
	
	@FindBy(id="addr")
	private WebElement address;
	
	@FindBy(name="zip")
	private WebElement zipcode;
	
	@FindBy(name="email")
	private WebElement email;
	
	@FindBy(name="sex")
	private WebElement gender;
	
	
	
	
}
