package com.cg;

import static org.junit.Assert.assertEquals;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestStepDefinition {

	WebDriver driver;

	@Given("User is on the registration page")
	public void user_is_on_the_registration_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver", "c:\\sel-jars/chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("C:\\HTML-Pages/RegistrationForm.html");
	}

	/*
	 * in the given RegistratoinForm HTML page Title is "Empty" so after doing
	 * changes to the verified the title
	 */
	@Then("Verify the title of the page")
	public void verify_the_title_of_the_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		assertEquals("Welcome to JobsWorld", driver.getTitle());
		if (driver.getTitle().equals("Welcome to JobsWorld")) {
			System.out.println("Title is matched :" + driver.getTitle());
		} else {
			System.out.println("Title not matched :" + driver.getTitle());
		}
	}
	/*
	 * in case if we need to test the scenario without doing the changes in the html
	 * page we can use the below snippet
	 */
	/*
	 * @Then("Verify the title of the page") public void
	 * verify_the_title_of_the_page() throws Throwable { // Write code here that
	 * turns the phrase above into concrete actions assertEquals("",
	 * driver.getTitle()); if (driver.getTitle().equals("")) {
	 * System.out.println("Title is matched :"+driver.getTitle()); } else {
	 * System.out.println("Title not matched :"+driver.getTitle()); } }
	 */
	
	@When("User leaves user id empty and length is not appropriate")
	public void user_leaves_user_id_empty_and_length_is_not_appropriate() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display user id alert message")
	public void display_user_id_alert_message() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("User leaves password empty and length is not appropriate")
	public void user_leaves_password_empty_and_length_is_not_appropriate() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display password alert message")
	public void display_password_alert_message() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("User leaves name empty and is not appropriate")
	public void user_leaves_name_empty_and_is_not_appropriate() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display name alert message")
	public void display_name_alert_message() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("User is using inAppropriate characters for address")
	public void user_is_using_inAppropriate_characters_for_address() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display address alert message")
	public void display_address_alert_message() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("User selects no country")
	public void user_selects_no_country() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display country alert message")
	public void display_country_alert_message() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("User enters wrong format")
	public void user_enters_wrong_format() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display zipcode alert message")
	public void display_zipcode_alert_message() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("User enters invalid email address")
	public void user_enters_invalid_email_address() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display invalid email alert message")
	public void display_invalid_email_alert_message() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("User leaves gender")
	public void user_leaves_gender() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@Then("display gender alert message")
	public void display_gender_alert_message() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new cucumber.api.PendingException();
	}

	@When("User enters the details correctly in the registration page")
	public void user_enters_the_details_correctly_in_the_registration_page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
		driver.findElement(By.id("usrID")).sendKeys("prudhviraj");
		driver.findElement(By.id("pwd")).sendKeys("valyrian");
		driver.findElement(By.id("usrname")).sendKeys("GadamsettyPrudhviRaj");
		driver.findElement(By.id("addr")).sendKeys("Dno120Egattur");
		new Select(driver.findElement(By.name("country"))).selectByVisibleText("India");
		driver.findElement(By.name("zip")).sendKeys("600025");
		driver.findElement(By.name("email")).sendKeys("rathood@gmail.com");
		driver.findElement(By.name("sex")).click();
		Thread.sleep(5000);
	}

	@When("click on the submit")
	public void click_on_the_submit() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(By.name("submit")).click();

	}

	@When("alert message")
	public void alert_message() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		Alert alert = driver.switchTo().alert();
		String msg = alert.getText();
		Thread.sleep(3000);
		alert.accept();
		System.out.println("displayed alert message is :" + msg);
		driver.close();
		System.out.println("Test completed successfully");
	}

}
