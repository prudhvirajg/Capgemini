function myfunction()
{
if (document.CustomerForm.cname.value == "") 
{
	alert("Please Enter The Customer Name");
	}
else if (document.CustomerForm.add.value == "") 
	 {
		 alert("Please Enter Delivery Details");
		 }
else if (document.CustomerForm.no.value == "" &&  /^\d+$/.test(document.CustomerForm.no.value))
	 {
		 alert("Please Enter the Contact Details");
	 }
else{
var myWindow = window.open("", "D:\\2019\\BDD1\\CustomerDemo\\src\\test\\java\\html\\success.html", "");
    myWindow.document.write("<h1>place order successful</h1>");
	
}


	}