import java.util.Scanner;
class Increasingnumber
{
                   //method to check if a number is an increasing number
                   public static boolean increasingnumber(int c)
                    {
                       int cd,n,flag=0;
                        cd=c%10;
                        n=c/10;
                        while(n>0)
                            {
                                if(cd<=n%10)
                              {
                                flag=1;
                                break;
                               }
                         cd=n%10;
                        n=n/10;                    
                       } 
                       if(flag==1)
                          return true;
                       else
                        return false;
                  }

                          public static void main(String[]args)
                    {
                         Scanner canon=new Scanner(System.in);
                         System.out.println("Enter a number to find whether it is an increasing number");
                         int a=canon.nextInt();
                       boolean b=increasingnumber(a);
                          if(b==true)
                            {
                              System.out.println("The given number is not an increasing number");
                            }
                          else if(b==false)
                           {
                              System.out.println("The given number is an increasing number");
                          }         
                   } 
}