import java.util.Scanner;
class Demo4
{
  public static void main(String[]args)
   {
               //program for addition of two numbers using scanner class
               //Scanner classs jave .util package
                 Scanner sc=new Scanner(System.in);
                 System.out.println("Accept first number");
                  int a=sc.nextInt();
                  System.out.println("Accept second number");
                  int b=sc.nextInt();
                  int c;
                  c=a+b;

         System.out.println("addition of "+a+" and "+b+" is "+c);
   }
}
