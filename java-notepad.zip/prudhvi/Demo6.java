import java.util.Scanner;
class Demo6
{
  public static void main(String[]args)
   {
               //program for addition of two numbers using scanner class
               //Scanner classs jave .util package
                 Scanner s1=new Scanner(System.in);
                 System.out.println("Employee_id");
                  int a=s1.nextInt();
                  System.out.println("Name of the employee");
                  String b=s1.nextline();
                  System.out.println("Aadhar number");
                  long c=s1.nextLong();
                  System.out.println("Salary");
                  double d=s1.nextDouble();
                           System.out.println("Name of the employee is "+b);
                           System.out.println("Employee_id of the employee is "+a);
                           System.out.println("Aadhar number of the employee is "+c); 
                           System.out.println("Salary of the employee is "+d);
   }
}
