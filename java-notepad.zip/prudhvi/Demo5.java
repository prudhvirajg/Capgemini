class Demo5
{
  public static void main(String[]args)
   {
               
                 Double a,c;
                 a=Double.parseDouble(args[0]);
                 c=3.14*a*a;

         System.out.println("Area of circle with Radius "+a+" is "+c);
   }
}
