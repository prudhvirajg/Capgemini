import java.util.Scanner;
class Calculatesum
{ 
                  /*a method which can calculate the sum of first n natural
                      numbers which are divisible by 3 or 5.*/
                    public static int calculatesum(int p)
                   {    
                           int total=0;
                           for(int i=1;i<=p;i++)
                        {
                             if(i%3==0||i%5==0)
                            total=total+i;
                          }                         
          return total;    
            }
                       public static void main(String[]args)
                    {
                        Scanner sin=new Scanner(System.in);                                
                        System.out.println("Enter the number");
                        int n=sin.nextInt();
                       int q=calculatesum(n);
                      System.out.println("sum of first"+n+" natural numbers which are divisible by 3 or 5 is:"+q);
                     }
}


































