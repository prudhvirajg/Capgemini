class Day210
{       
                                public static void forloop() 
            {
                             for(int a=1;a<=3;a++)
                            {
                                    for(int b=1;b<=3;b++)
                                       { 
                                             if(a==2)
                                           break;
                                            System.out.print(a+","+b+" ");
                                        }
                               System.out.println();
                           }                           
            }  
             public static void labelforloop()
       {
                 OUTER:for(int a=1;a<=3;a++)
                    {
                                  INNER:  for(int b=1;b<=3;b++)
                                       { 
                                             if(a==2)
                                           break OUTER;
                                            System.out.print(a+","+b+" ");
                                        }
                               System.out.println();
                           }                   
        }

                   public static void main(String[]args)
                             {
                              forloop();
                              System.out.println("==================");
                              labelforloop();
                             }

}


