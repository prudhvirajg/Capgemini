import java.io.*;
class Day28
{       
                                public static void whileloop() throws IOException
            {
                               BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                                 String s="";     
                                 while(! s.equals("stop"))
                                            {         
                                                      s=br.readLine();
                                                           System.out.println("Line is "+s);
                                               }
               }
               public static void main(String[]args) throws IOException
       {
                 whileloop();
        }
}