import java.util.Scanner;
class Day25
{       
                //this checks for no of days in a month 
                 public static String checkdays(int d)
            {
                String p;
                switch(d)
                      {
                             case 1:
                             case 3:
                             case 5:
                             case 7:
                             case 8:
                             case 10:
                             case 12:
                                           p="31 days";
                                              break;
                               case 4: 
                                case 6:
                                case 9:
                                case 11:
                                            p="30 days";
                                              break;
                                case 2:
                                           p="28/29 days";
                                                break;
                                default:
                                         p="invalid i/p";                          
                       }
              return p;
              }  
                 public static void main(String[]args)
       {
                  String war=checkdays(2);
                  System.out.println(war);

                 war=checkdays(10);
                  System.out.println(war);
                  
                 war=checkdays(15);
                  System.out.println(war);
       
                   war=checkdays(6);
                  System.out.println(war);

                 war=checkdays(11);
                  System.out.println(war);

                      war=checkdays(8);
                  System.out.println(war);
        }
}