import java.util.Scanner;
class Assign4_salaries
{
                      public static void main(String[]args)
                    {
                        Scanner sin=new Scanner(System.in);                                
                        System.out.println("Enter the number of salaries you want to calculate");
                        int n=sin.nextInt();
                        int a[]=new int[n];
                        for(int i=0;i<n;i++)
                     {
                         System.out.println("Enter the Salary");
                              a[i]=sin.nextInt();
                       }
                        int shot=0;
                         for(int j=0;j<n;j++)
                          {
                                     shot=shot+a[j];                     
                          }
                   System.out.println("sum of all the salaries:"+shot);
                   }
}




































