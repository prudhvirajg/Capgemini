public class Employee
{
                  private int eid;
                   private String empName;
                   private double salary;
//default constructor
             public Employee()
                        {
                          eid=1;
                          empName="shar";
                          salary=1000.00;
                          }
    //overloaded parameterised constructor
             public Employee(int id,String name,double sal)
          { this.setEid(id);
            this.setEmpName(name);
             this.setSalary(sal);
              }

//setter methods=javabean conventions
                public void setEid(int eid)
                 { 
//default access given to local variable
                    if(eid>0)
                    this.eid=eid;
//this.eid here refers to instance variable
                 }
             public void setEmpName(String name)
                 {
                   if (name!=null)
                    empName=name;
                  }
              public void setSalary(double sal)
                 {
                   if (sal>0.0)
                    salary=sal;            
    }
//getter method
   public int getEid()
         {return eid;  
}
  public String getEmpName()
            { return empName;
}                 
public double getSalary()
     {        return salary;
}          

           public void printDetails()        
         {  
             System.out.println("Eid "+eid+" EmpName "+empName+" EmpSalary "+salary); 
         }
}