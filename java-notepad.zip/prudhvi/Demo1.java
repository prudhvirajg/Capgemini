class Demo1
{
  public static void main(String[]args)
   {
               //program for addition of two numbers
                 int a=30,b=60,c; 
                 c=a+b;

         System.out.println("addition of "+a+" and "+b+" is "+c);
   }
}
