class Demo3
{
  public static void main(String[]args)
   {
               //program for addition of two numbers using command line arguments
                 int a=Integer.parseInt(args[0]),b=Integer.parseInt(args[1]),c; 
                 c=a+b;

         System.out.println("addition of "+a+" and "+b+" is "+c);
   }
}
