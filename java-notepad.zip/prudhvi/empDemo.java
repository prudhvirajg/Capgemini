class Employee
{
                   int eid;
                   String empName;
                   double salary;
              public void printDetails()        
         {  
             System.out.println("Eid "+eid+" EmpName "+empName+" EmpSalary "+salary); 
         }
}
  public class EmpDemo
 {
        public static void main(String[]args)
   {
         Employee e1=new Employee();
          e1.eid=100;
         e1.empName="suhas";
         e1.salary=45000;
         e1.printDetails();

        Employee e2=new Employee();
          e2.eid=110;
         e2.empName="martin";
         e2.salary=55000;
         e2.printDetails(); 
      }
  }