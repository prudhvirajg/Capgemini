import java.util.Scanner;
class Assign2_max
{          
                  public static void main(String[]args)
                   {
                  Scanner sc=new Scanner(System.in);                 
                  int a[]=new int[5];       
                 System.out.println("enter any 5 numbers for finding the max number");         
                  for(int i=0;i<5;i++)
                        {
                           a[i]=sc.nextInt();                                   
                       }

                      int pint;              
                        for(int h=0;h<5;h++)
                             {
                                   for(int c=h+1;c<5;c++)
                                {
                                      if(a[h]>a[c])
                                          { 
                                               pint=a[h];
                                                  a[h]=a[c];
                                               a[c]=pint;
                                          }                                  
                                   }
                              }  
                                 System.out.print("The maximum/highest number is:");     
                                 System.out.print(a[4]);   
                           }
}