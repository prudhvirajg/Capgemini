 public class empDemo2
 {
        public static void main(String[]args)
   {
         Employee e1=new Employee();
         
         e1.printDetails();

        Employee e2=new Employee(100,"rathood",60000);
        
       
         e2.printDetails(); 
      }
  }