
class Day27
{       
                //this checks for no of days in a month name
                 public static void forloop()
            {
                    for(int a=1;a<=15;a++)
                      {
                           System.out.println(a);
                      }
              }  
                   public static void whileloop()
            {
                    int a=1;
                     while(a<=15)
                      {
                           System.out.println(a);
                            a+=2;
                      }
              }  
                     public static void dowhileloop()
            {
                    int a=18;
                     do
                      {
                           System.out.println(a);
                            a+=3;
                       
                        } 
                             while(a<=15);                      
                                   }  
                public static void main(String[]args)
       {
                  forloop();
                  System.out.println("-------------------------------");
                  whileloop();            
                  System.out.println("--------------------------------");      
                  dowhileloop();
                  System.out.println("--------------------------------");          
        }
}