import java.util.Scanner;
class Assign1_sort
{          
                 public static void sortProcess(int b[])
                {
                      int pint;              
                        for(int h=0;h<5;h++)
                             {
                                   for(int c=h+1;c<5;c++)
                                {
                                      if(b[h]>b[c])
                                          { 
                                               pint=b[h];
                                                  b[h]=b[c];
                                               b[c]=pint;
                                          }                                  
                                   }
                              }  
                                 System.out.println("ascending order");     
                                for(int k=0;k<5;k++)
                                          { 
                                                 System.out.println(b[k]);
                                          }            
                    } 
                 public static void main(String[]args)

                   {
                  Scanner sc=new Scanner(System.in);                 
                  int a[]=new int[5];       
                 System.out.println("enter 5 numbers for sorting");         
                  for(int i=0;i<5;i++)
                        {
                                   
                                   a[i]=sc.nextInt();                                   
                     }
                             sortProcess(a);
                   }

}