class Demo2
{
  public static void main(String[]args)
   {
               //program for subtraction of two numbers
                 int a=30,b=60,c; 
                 c=a-b;

         System.out.println("subtraction of "+a+" and "+b+" is "+c);
   }
}
