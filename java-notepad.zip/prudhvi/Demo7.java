import java.io.*;
class Demo7
{
  public static void main(String[]args) throws IOException
   {
              //program using buffered reader

                 BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                  System.out.println("Employee_id");
                  String seid=br.readLine();
                  int eid=Integer.parseInt(seid);
                  
                  System.out.println("Name of the employee");
                  String sname=br.readLine();
                  
                  System.out.println("Aadhar number");
                  String saadhar=br.readLine();
                  Long aadhar=Long.parseLong(saadhar);
 
                  System.out.println("Salary");
                  String ssal=br.readLine();
                  double sal=Double.parseDouble(ssal);

                           System.out.println("Name of the employee is "+sname);
                           System.out.println("Employee_id of the employee is "+eid);
                           System.out.println("Aadhar number of the employee is "+aadhar); 
                           System.out.println("Salary of the employee is "+sal);
   }
}
