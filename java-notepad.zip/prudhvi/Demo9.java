class Demo9
{
     public static void main(String[]args)
{
            int i=15;
          System.out.println((i++)+" "+(i--)+" "+(++i)+" "+(--i)+" "+(i+=3)+" "+(i-=3)+" "+(i*=3)+" "+(i/=3)+" "+(i%=3));
  int a=20,b=17,c;
 
              if(a>=15 && b>=10)
                c=1;
              else
            c=0;
           System.out.println(+c);

           int d=10,e;
          if(d!=5)
e=1;
      else 
e=0;

          System.out.println(+e);

//bitwise
        
          int f=7,g=5;
System.out.println((f&g)+" "+(f|g)+" "+(f^g)+" "+(~b));
//shift 


int h=15;
System.out.println((h<<5)+" "+(h>>2)+" "+(h>>>5));
            

        }
}