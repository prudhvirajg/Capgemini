import java.util.Scanner;
class Day26
{       
                //this checks for no of days in a month name
                 public static String checkdays(String d)
            {
                String p;
                switch(d)
                      {
                             case "jan":
                             case "mar":
                             case  "may":
                             case "jul":
                             case "aug":
                             case "oct":
                             case "dec":
                                           p="31 days";
                                              break;
                               case "apr": 
                                case "jun":
                                case "sep":
                                case "nov":
                                            p="30 days";
                                              break;
                                case "feb":
                                           p="28/29 days";
                                                break;
                                default:
                                         p="invalid i/p";                          
                       }
              return p;
              }  
                 public static void main(String[]args)
       {
                  Scanner xp=new Scanner(System.in);
                  System.out.println("enter month");
                  String h=xp.next();
                  String war=checkdays(h);
                  System.out.println(war);              
        }
}