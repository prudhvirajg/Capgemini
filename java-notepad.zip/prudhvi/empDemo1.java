 public class empDemo1
 {
        public static void main(String[]args)
   {
         Employee e1=new Employee();
          e1.setEid(100);
         e1.setEmpName("suhas");
         e1.setSalary(-45000);
         e1.printDetails();

        Employee e2=new Employee();
          e2.setEid(110);
         e2.setEmpName("martin");
         e2.setSalary(55000);
         e2.printDetails(); 
      }
  }