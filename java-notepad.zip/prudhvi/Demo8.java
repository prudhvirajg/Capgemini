class Demo8
{
     public static void main(String[]args)
{
 
            int a1=25;
            int a2=025;
            int a3=0x25;
            int a4=0b1001_1101;
     
          System.out.println(" integer values are "+a1+" "+a2+" "+a3+" "+a4);



            char c1='q';
            char c2='\u0032';
            char  c3=16;
          System.out.println("char values are"+c1+" "+c2+" "+c3);
 
           long l1=5875475;
           long l2=234;
           System.out.println("long values are"+l1+" "+l2);

  
           float f1=10;
           float f2=1054725254;
           float f3=4242;
           System.out.println("float values are"+f1+" "+f2+" "+f3);

           double d1=51454.4534;
           double d2=.545;
           double d3=534534.242534;
           System.out.println("double values are "+d1+" "+d2+" "+d3);


        }
}