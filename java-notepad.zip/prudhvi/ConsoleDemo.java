import java.io.Console;
public class ConsoleDemo
{
   public static void main(String[]args)
            {
                       Console c=System.console();
                       System.out.println("Enter USername");
                      String user =c.readLine();
                     System.out.println("Enter Password");
                     String pwd=new String(c.readPassword());
                      if(user.equals("cg")&&pwd.equals("gemioni"))
                             {
                                     System.out.println("Authorized user");
                             }
                    else
                             {
                                   System.out.println("Unauthorized user");
                           }
             }
}