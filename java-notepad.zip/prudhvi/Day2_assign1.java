import java.util.Scanner;
class Day23
{

       
                //this checks grade as percentage
                 public static double calculateBonus(double pct)
            {
                 double bonus;
                  if(pct>=50000)
                    bonus =(pct/100*50);
                  else if(pct>=30000)
                     bonus=(pct/100*30);
                  else
                     bonus=(pct/100*20);
             return bonus;
              }

       
                 public static void main(String[]args)

       {
                  Scanner sc=new Scanner(System.in);
                  System.out.println("Enter Salary");
                  double a=sc.nextDouble();
                  double result=calculateBonus(a);
                  System.out.println("Bonus is "+result);


        }



}