import java.util.Scanner;
class Day21
{

{
                \\this checks the eligibility for voting
                 public static void votingEligibility(inta age)
{
               if(age>=18)
                   { 
                     system.out.println("elgible for voting);
                   }
              else
                   {
                      system.out.println("not eligible for voting");
                   }

}

}
                 public static void main(String[]args)

{
                  Scanner sc=new Scanner(System.in);
                  system.out.println("enter age);
                  int a=nextInt();
                   votingEligibility(a);


}



}