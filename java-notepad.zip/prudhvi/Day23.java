import java.util.Scanner;
class Day22
{

       
                //this checks grade as percentage
                 public static String calculateGrade(double pct)
            {
                 String grade;
                  if(pct>=90 && pct<=100)
                     grade="A+";
                  else if(pct>=70)
                     grade="A";
                  else if(pct>=50)
                     grade="B";
                  else
                     grade="Fail";
             return grade;
              }

       
                 public static void main(String[]args)

       {
                  Scanner sc=new Scanner(System.in);
                  System.out.println("enter percen");
                  double a=sc.nextDouble();
                  String result=calculateGrade(a);
                  System.out.println("grade is "+result);


        }



}