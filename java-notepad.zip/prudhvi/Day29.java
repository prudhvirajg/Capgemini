class Day29
{       
                                public static void forloop() 
            {
                             for(int a=1;a<=30;a++)
                            {
                             
                                     if(a==10)
                                           continue;
                                   
                               System.out.println(a);
                                      if(a==25)
                                    break;
                              
                            }
            }  
             public static void main(String[]args) 
       {
                 forloop();
        }
}