import java.util.Scanner;
class Checknumber
{                 
                   /*method to check if a number is a power of two or not*/
                    public static boolean checknumber(int p)
                   {    
                         int g=0;
                         if(p>0)
                             { 
                              while(p%2==0)
                                   {
                                      p=p/2;
                                    }
                                  if(p==1)
                                    {        g=1; }                                           
                                   }
                             if(p==0||p!=1)
                                     {g=0; }
               if(g==1)
          return true;
              else
          return false;                    
                     }
                       public static void main(String[]args)
                    {
                        Scanner sin=new Scanner(System.in);                                
                        System.out.println("Enter the number");
                        int n=sin.nextInt();
                       boolean q=checknumber(n);
                           if(q==true)
                      System.out.println(n+" is a power of two");
                          else if(q==false)
                        System.out.println(n+" is not a power of two");
                     }
}


































