 public class empDemo4
 {
                public void changeobj(Employee e)
                    {     
                        e.setSalary(50000.00);
                        }
        public static void main(String[]args)
   {
                    empDemo4 ob=new empDemo4(); 
                      Employee e=new Employee(100,"kishan",25000.00);
                      e.printDetails();
                          ob.changeobj(e);
                     e.printDetails();
      }
  }