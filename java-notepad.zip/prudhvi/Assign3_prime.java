import java.util.Scanner;
class Assign3_prime
{          
                  public static void main(String[]args)
                   {
                  Scanner sc=new Scanner(System.in);      
                 int p,q=0 ;     
                 System.out.println("enter a positive number");
                           p=sc.nextInt(); 
                                                                                                                            
                      for(int i=2;i<=p/2;++i)
                            { 
                                      if(p%i==0)
                                   {
                                        q=1;
                                        break;
                                   }
                               }
                    if(p==1)                                
                    { System.out.println(p+"is neither a prime number nor a composite number");}
                       else
                             {                 
                                    if(q==1)
                               {
                                        System.out.println(p+"is a composite number");
                                  }
                                  else
                                    {   
                                         System.out.println(p+"is a prime number");}
                                  }                                          
                           }
}
