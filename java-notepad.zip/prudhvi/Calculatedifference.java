import java.util.Scanner;
class Calculatedifference
{                 
                   /*method to find the difference between the sum of the
squares and the square of the sum of the first n natural numbers*/
                    public static int calculatediff(int p)
                   {    
                           int sum_of_the_squares=0,square_of_the_sum,a,b=0,c;
                           for(int i=1;i<=p;i++)
                        {
                             a=i*i; 
                            sum_of_the_squares=sum_of_the_squares+a;
                            b=b+i;
                          }
                         square_of_the_sum=b*b;
                           c=-(sum_of_the_squares-square_of_the_sum);
          return c;    
            }
                       public static void main(String[]args)
                    {
                        Scanner sin=new Scanner(System.in);                                
                        System.out.println("Enter the number");
                        int n=sin.nextInt();
                       int q=calculatediff(n);
                      System.out.println("difference between the sum of the squares of the first "+n+
                                                          "natural numbers and the square of their sum: "+q);
                     }
}


































