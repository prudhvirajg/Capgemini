 public class empDemo3
 {
                public void change(int x)
                    {     
                        x=x*2;
                        }
        public static void main(String[]args)
   {
                    empDemo3 ob=new empDemo3();
                         int x=100;                      
                      System.out.println(x);
                          ob.change(x);
                         System.out.println(x);
      }
  }