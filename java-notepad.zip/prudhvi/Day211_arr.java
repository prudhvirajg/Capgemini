import  java.util.Scanner;
class Day211
{                             
        public static void main(String[]args)
                   {
                           int a[][]=new int[3][3];
                              Scanner xp=new Scanner(System.in);
                              for(int i=0;i<3;i++)
                                    {
                                        for(int j=0;j<3;j++)
                                              {
                                                   a[i][j]=xp.nextInt();
                                               }    
                                     }      
                                    for(int i=0;i<3;i++)
                                    {
                                        for(int j=0;j<3;j++)
                                              {
                                                   System.out.print(a[i][j]+" ");
                                               }    
                                        System.out.println();
                                     }       
                     }
}


