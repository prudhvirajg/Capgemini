import java.util.Scanner;
class Day25
{       
                //this checks for no of days in a month name
                 public static String checkdays(String d)
            {
                String p;
                switch(d)
                      {
                             case "jan":
                             case "mar":
                             case  "may":
                             case "jul":
                             case "aug":
                             case "oct":
                             case "dec":
                                           p="31 days";
                                              break;
                               case "apr": 
                                case "jun":
                                case "sep":
                                case "nov":
                                            p="30 days";
                                              break;
                                case "feb":
                                           p="28/29 days";
                                                break;
                                default:
                                         p="invalid i/p";                          
                       }
              return p;
              }  
                 public static void main(String[]args)
       {
                  String war=checkdays("jun");
                  System.out.println(war);

                 war=checkdays("apr");
                  System.out.println(war);
                  
                 war=checkdays("bat");
                  System.out.println(war);
       
                   war=checkdays("dec");
                  System.out.println(war);

                 war=checkdays("nov");
                  System.out.println(war);

                      war=checkdays("aug");
                  System.out.println(war);
        }
}