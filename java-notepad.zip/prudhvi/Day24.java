import java.util.Scanner;
class Day24
{

       
                //this checks whether the given letter vowel or consonant
                 public static String checkvowel(char ch)
            {
                String s;
                switch(ch)
                      {
                             case 'A':
                             case 'E':
                             case 'I':
                             case 'O':
                             case 'U':
                                           s="vowell";
                                              break;
                                default:
                                       s="consonant";                          
                       }
              return s;
              }

       
                 public static void main(String[]args)

       {
                  String war=checkvowel('B');
                  System.out.println(war);

                 war=checkvowel('O');
                  System.out.println(war);

                  
                  war=checkvowel('A');
                  System.out.println(war);
       
                    war=checkvowel('K');
                  System.out.println(war);


        }



}