package com.cg.app;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.app.intro.CurrencyConverter;
import com.cg.models.Department;
import com.cg.models.Employee;

import org.springframework.context.ApplicationContext;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");


CurrencyConverter converter=context.getBean(CurrencyConverter.class);
double amountInRupees=converter.dollarsToRupees(100);
System.out.println("amount "+amountInRupees);
Employee emp=context.getBean(Employee.class);
Department dept=context.getBean(Department.class);
System.out.println("hello "+emp.getFirstname());
System.out.println("is emp.department and dept are same ? "+ (emp.getDepartment()==dept));
	
	}

}
