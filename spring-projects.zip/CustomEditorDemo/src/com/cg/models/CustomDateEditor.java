package com.cg.models;

import java.beans.PropertyEditorSupport;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.expression.ParseException;

public class CustomDateEditor  extends PropertyEditorSupport	{

private DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
@Override
public String getAsText() {
	return df.format(getValue());
}

@Override
public void setAsText(String text) throws IllegalArgumentException {
	try {
		setValue(df.parse(text));
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		throw new IllegalArgumentException("Invalid Date syntax, please use dd-MM-yyyy");
	}
  }
}
