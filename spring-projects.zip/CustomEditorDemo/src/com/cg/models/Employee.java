package com.cg.models;



import java.sql.Date;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Employee {
private String firstname;
private String lastname;
private Date dob;
private Department department;

@PostConstruct
public void init() {
	System.out.println("after object created"+" before it is invoked using getbean");
}
@PreDestroy
public void destroy() {
	System.out.println("melodrama at destroy");
}

public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}

public Date getDob() {
	return dob;
}
public void setDob(Date dob) {
	this.dob = dob;
}
public Department getDepartment() {
	return department;
}
public void setDepartment(Department department) {
	this.department = department;
}



}
