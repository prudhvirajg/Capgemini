package com.cg.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.models.*;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context =
				new ClassPathXmlApplicationContext("spring.xml");
			Employee e = context.getBean(Employee.class);
			System.out.println(e.getFirstname());
			System.out.println(e.getLastname());
			System.out.println(e.getDepartment().getLocation());
			System.out.println(e.getDepartment().getName());
		

			System.out.println("Shutdown the Spring IOC COntainer");
			context.close();
	}

}
