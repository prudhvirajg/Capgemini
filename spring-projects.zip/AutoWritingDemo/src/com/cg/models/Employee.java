package com.cg.models;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
@Component("employee")
public class Employee {
	
	@Value("ram")
private String firstname;
	@Value("nath")
private String lastname;
@Autowired
private Department department;

@PostConstruct
public void init() {
	System.out.println("after object created"+" before it is invoked using getbean");
}
@PreDestroy
public void destroy() {
	System.out.println("melodrama at destroy");
}

public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public Department getDepartment() {
	return department;
}
public void setDepartment(Department department) {
	this.department = department;
}




}
