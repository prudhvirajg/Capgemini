package com.cg.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.models.Employee;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
       
       Employee emp=context.getBean(Employee.class);
       System.out.println("Employee details\n=================");
       System.out.println("Employee id: "+emp.getEmpId());
       System.out.println("Employee name: "+emp.getEmpName());
       System.out.println("Employee Salary: "+emp.getSalary());
       System.out.println("Employee Business Unit: "+emp.getBusinessUnit());
       System.out.println("Employee Age: "+emp.getAge());
       
       
	}

}
