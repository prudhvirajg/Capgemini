package com.cg.bookassignment.services;

import java.util.List;

import com.cg.bookassignment.entities.Book;

public interface BookService {

	
	public List<Book> books();
}
