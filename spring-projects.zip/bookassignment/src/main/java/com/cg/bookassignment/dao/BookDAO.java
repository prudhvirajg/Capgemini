package com.cg.bookassignment.dao;

import java.util.List;

import com.cg.bookassignment.entities.Book;

public interface BookDAO {
public List<Book> books();
}
