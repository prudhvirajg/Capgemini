package com.cg.bookassignment.dao;

import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.bookassignment.entities.Book;

@Repository
public class BookDAOImpl implements BookDAO {


	public List<Book> books() {
		List<Book> ps=new LinkedList<>();
		Book b1=new Book();
		b1.setId(100);
		b1.setTitle("Two States");
		b1.setAuthor("Chetan Bhagath");
		Book b2=new Book();
		b2.setId(101);
		b2.setTitle("Harry Potter and the sorceror's Stone");
		b2.setAuthor("J.K.Rowlig's");
		Book b3=new Book();
		b3.setId(100);
		b3.setTitle("Harry potter and the prisoner of azkabhan");
		b3.setAuthor("J.K.Rowlig's");
		
		ps.add(b1);
		ps.add(b2);
		ps.add(b3);
		return ps;
	
	}

}
