package com.cg.bookassignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookassignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookassignmentApplication.class, args);
	}

}
