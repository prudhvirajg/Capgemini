package com.cg.bookassignment.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bookassignment.dao.BookDAO;
import com.cg.bookassignment.entities.Book;

@Service

public class BookServiceImpl implements BookService {

	@Autowired private BookDAO dao;
	@Override
	public List<Book> books() {
		// TODO Auto-generated method stub
		
		return dao.books();
	}

	

}
