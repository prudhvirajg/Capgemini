package com.cg.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.models.Customer;

@Controller
public class CustomerController {
@RequestMapping(value="/add-customer.obj",method=RequestMethod.GET)

public ModelAndView showForm() {
	ModelAndView mv=new ModelAndView("form");
	Customer customer=new Customer();
	mv.addObject("customer", customer);
	return mv;
 }
@RequestMapping(value="/add-customer.obj",method=RequestMethod.POST)
public ModelAndView submitForm(@ModelAttribute("customer") Customer customer) {
	ModelAndView mv=new ModelAndView("success");
	System.out.println("Accepting Customer object: ");
	mv.addObject("customer", customer);
	mv.addObject("message", "your requested has been accepted");
	return mv;
}
}
