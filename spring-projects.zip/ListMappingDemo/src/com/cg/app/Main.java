package com.cg.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.models.Department;
import com.cg.models.Employee;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		
	
		Department dept=context.getBean(Department.class);
		for (Employee w:dept.getEmployees())
				{
			System.out.println(w.getFirstName()+" "+w.getLastName());
			
		}
		 

}
}



