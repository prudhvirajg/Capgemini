package com.cg.models;

import org.springframework.context.annotation.*;

@Configuration
public class AppConfig {
@Bean
@Scope("singleton")
public Department dept() {
	Department d=new Department();
	d.setName("WWE");
	return d;
}
@Bean
public Employee emp() {
	Employee e=new Employee();
	e.setName("floyd may weather");
	e.setDepartment(dept());
	return e;
}

}
