package com.cg.account.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.account.entities.Account;
import com.cg.account.services.AccountService;

@RestController
@RequestMapping("/accounts")
public class AccountController {

	@Autowired
	private AccountService service;

	// test url:http://localhost:8080/accounts/mobileno
	@GetMapping(value = "/mobileno{mobileno}", produces = { "application/json", "application/xml" })
	public Account search(@PathVariable String mobileno) {
		return service.search(mobileno);
	}

	// test url:http://localhost:8080/accounts/create
	@PostMapping(value = "/create", consumes = { "application/json", "application/xml" })
	public ResponseEntity<String> create(@RequestBody Account acc) {
		System.out.println("Create");
		service.create(acc);
		// Return Response body "Record Created" with response status=201
		return new ResponseEntity<String>("Account Created successfully", HttpStatus.CREATED);
	}

	// USE DELETE MAPPING,USE either @REQUESTEDPARAM OR @PATHVARIABLE
	// test url:http://localhost:8080/accounts/delete9505275222
	@DeleteMapping(value = "/delete{mobileno}")
	//
	public ResponseEntity<String> delete(@PathVariable String mobileno) {
		service.delete(mobileno);
		return new ResponseEntity<String>("Account deleted successfully", HttpStatus.OK);
	}

	// http://localhost:8080/accounts/addmoney/950527523/5000
	@PutMapping(value = "/addmoney/{mobileno}/{amount}")
	public ResponseEntity<String> addmoney(@PathVariable String mobileno, @PathVariable double amount) {
		service.addMoney(mobileno, amount);
		return new ResponseEntity<String>("Money Added successfully", HttpStatus.OK);
	}

	// http://localhost:8080/accounts/transfermoney/950527523/9505275222/5000
	@PutMapping(value = "/transfermoney/{mobileno1}/{mobileno2}/{amount}")
	public ResponseEntity<String> Transfermoney(@PathVariable String mobileno1, @PathVariable String mobileno2,
			@PathVariable double amount) {
		service.transferMoney(mobileno1, mobileno2, amount);
		return new ResponseEntity<String>("Money Transfered successfully", HttpStatus.OK);

	}

	// http://localhost:8080/accounts/withdraw/950527523/5000
	@PutMapping(value = "/withdraw/{mobileno}/{amount}")
	public ResponseEntity<String> Withdrawmoney(@PathVariable String mobileno, @PathVariable double amount) {
		service.WithDraw(mobileno, amount);
		return new ResponseEntity<String>("Money withdrawed successfully", HttpStatus.OK);
	}
	// http://localhost:8080/accounts/accountdetails
		@GetMapping(value = "/accountdetails")
		public List<Account> getAllAccounts() {
			return service.getAllAccount();
		}
}
