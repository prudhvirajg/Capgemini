package com.cg.account.services;

import java.util.List;

import com.cg.account.entities.Account;

public interface AccountService {
	void create(Account ac);
	Account search(String mobileno);
	void delete(String mobileno);
	Account addMoney(String mobileno,double amount);
    String transferMoney(String mobileno1,String mobileno2,double amount);
    Account WithDraw(String mobileno,double amount);
    List<Account> getAllAccount();
}
