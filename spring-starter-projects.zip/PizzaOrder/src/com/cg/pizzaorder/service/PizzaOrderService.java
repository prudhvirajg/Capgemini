package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public class PizzaOrderService implements IPizzaOrderService{

	@Override
	public int placeOrder(Customer customr, PizzaOrder pizza) {
		
		return 0;
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int GenOrderId() {
		int orderId = (int) (Math.random()*1000);
		return orderId;
	}

	@Override
	public int GenCustId() {
		int custId = (int) (Math.random()*1000);
		return custId;
	}

	@Override
	public boolean validatePhone(String mobile) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
