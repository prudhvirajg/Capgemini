package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public interface IPizzaOrderService {
	String mobilePattern="[6-9] {0-9}{9}";
	public int placeOrder(Customer customr, PizzaOrder pizza);
	public PizzaOrder getOrderDetails(int orderId);
	
	public int GenOrderId();
	public int GenCustId();
	public boolean validatePhone(String mobile);
}
