package com.cg.pizzaorder.ui;

import java.io.*;

public class Client {

	public static void main(String[] args) throws NumberFormatException, IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter Option :");
		System.out.println("1) Pizza Order\n2) Order Id\n3) Exit");
		
		int a = Integer.parseInt(br.readLine());
		
			switch(a) {
			case 1:
				System.out.println("Enter Customer Name");
				String custName = br.readLine();
				
				System.out.println("Enter Mobile Number");
				String custMobile = br.readLine();
				
				System.out.println("Enter Customer Address");
				String custAddress = br.readLine();
				break;
				
			case 2:
				System.out.println("Enter Order Id");
				int o = Integer.parseInt(br.readLine());
				break;
				
			case 3:
				System.exit(0);
				
			}
		
	}

}
