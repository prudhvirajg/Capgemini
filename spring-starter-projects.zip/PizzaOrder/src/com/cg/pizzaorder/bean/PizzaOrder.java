package com.cg.pizzaorder.bean;

public class PizzaOrder {
	private int custId;
	private int orderId;
	private double price;
	public PizzaOrder(int custId, int orderId, double price) {
		super();
		this.custId = custId;
		this.orderId = orderId;
		this.price = price;
	}
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "PizzaOrder [custId=" + custId + ", orderId=" + orderId + ", price=" + price + "]";
	}
	
}
