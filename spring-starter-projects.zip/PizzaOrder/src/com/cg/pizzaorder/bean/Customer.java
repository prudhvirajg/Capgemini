package com.cg.pizzaorder.bean;

public class Customer {

	private String custName;
	private String custMobile;
	private String custAddress;
	public Customer(String custName, String custMobile, String custAddress) {
		super();
		this.custName = custName;
		this.custMobile = custMobile;
		this.custAddress = custAddress;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustMobile() {
		return custMobile;
	}
	public void setCustMobile(String custMobile) {
		this.custMobile = custMobile;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	@Override
	public String toString() {
		return "Customer [custName=" + custName + ", custMobile=" + custMobile + ", custAddress=" + custAddress + "]";
	}
	
}
