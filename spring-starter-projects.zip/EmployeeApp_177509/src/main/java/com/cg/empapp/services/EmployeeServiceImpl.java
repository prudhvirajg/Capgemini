package com.cg.empapp.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.empapp.bean.Employee;
import com.cg.empapp.dao.EmployeeDao;
import com.cg.empapp.exceptions.ApplicationException;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao dao;

	@Transactional
	public void createEmployee(Employee emp) {
		// TODO Auto-generated method stub
		if (dao.existsById(emp.getEmpid())) {
			throw new ApplicationException("Record already exists!");
		}
		dao.save(emp);
	}

	@Transactional
	public void upadteEmployee(Employee emp) {
		// TODO Auto-generated method stub

		dao.save(emp);
	}

	@Transactional
	public void deleteEmployee(Integer empid) {
		// TODO Auto-generated method stub
		if (!dao.existsById(empid)) {
			throw new ApplicationException("Unable to delete, record not found!");
		}
		dao.deleteById(empid);
	}

	@Transactional
	public List<Employee> viewEmployeeList() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Transactional
	public Employee findEmployee(Integer empid) {
		// TODO Auto-generated method stub
		Optional<Employee> temp = dao.findById(empid);
		if (!temp.isPresent()) {
			throw new ApplicationException("Unable to fetch employee " + empid);
		}
		return dao.findById(empid).get();
	}

}
