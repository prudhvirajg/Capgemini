package com.cg.empapp.services;

import java.util.List;

import com.cg.empapp.bean.Employee;

public interface EmployeeService {
	void createEmployee(Employee emp);

	void upadteEmployee(Employee emp);

	void deleteEmployee(Integer empid);

	List<Employee> viewEmployeeList();

	Employee findEmployee(Integer empid);
}
