package com.cg.empapp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "employee")
public class Employee {

	// here for empid(primary key) data type integer is used instead of string
	// since we can not auto increment a data type of string
	// where in the question it was asked to auto increment primary key

	@Id
	@Column(name = "empid")
	// @GeneratedValue(strategy=GenerationType.AUTO)
	// here it is unable to increment with above statement so creating all the
	// emp id's manually
	private Integer empid;

	@Column(name = "name")
	private String name;

	@Column(name = "designation")
	private String designation;

	@Column(name = "salary")
	private double salary;

	@Column(name = "deptname")
	private String deptname;

	public Integer getEmpid() {
		return empid;
	}

	public void setEmpid(Integer empid) {
		this.empid = empid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

}
