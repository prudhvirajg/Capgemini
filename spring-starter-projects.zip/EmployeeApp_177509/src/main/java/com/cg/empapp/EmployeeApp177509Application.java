package com.cg.empapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeApp177509Application {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeApp177509Application.class, args);
	}

}
