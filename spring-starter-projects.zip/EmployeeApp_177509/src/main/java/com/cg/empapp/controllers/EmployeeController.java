package com.cg.empapp.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.empapp.bean.Employee;
import com.cg.empapp.services.*;

@RestController

public class EmployeeController {
	@Autowired
	private EmployeeService service;

	@PostMapping(value = "/createemployee", consumes = { "application/json" })
	public ResponseEntity<String> createemployee(@RequestBody Employee emp) {
		System.out.println("Created employee");
		service.createEmployee(emp);
		return new ResponseEntity<String>("Employee Created successfully", HttpStatus.CREATED);
	}

	@PutMapping(value = "/updateemployee", consumes = { "application/json" })
	public ResponseEntity<String> updateemployee(@RequestBody Employee emp) {
		System.out.println("upadted employee ");
		service.upadteEmployee(emp);
		return new ResponseEntity<String>("updated Employee successfully", HttpStatus.OK);
	}

	@DeleteMapping(value = "/delete/{empid}")
	public ResponseEntity<String> delete(@PathVariable Integer empid) {
		service.deleteEmployee(empid);
		return new ResponseEntity<String>("Employee deleted successfully", HttpStatus.OK);
	}

	@GetMapping(value = "/employees")
	public List<Employee> getAllAccounts() {
		return service.viewEmployeeList();
	}

	@GetMapping(value = "/getbyid")
	public Employee search(@RequestParam Integer empid) {
		return service.findEmployee(empid);
	}

}
