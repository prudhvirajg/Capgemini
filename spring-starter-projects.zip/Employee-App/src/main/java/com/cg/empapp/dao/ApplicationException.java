package com.cg.empapp.dao;

public class ApplicationException extends RuntimeException{

	public ApplicationException(String message,Throwable cause) {
		super(message,cause);
		// TODO Auto-generated constructor stub
	}
	
	
	public ApplicationException(String message) {
		super(message);
	}
}
