package com.cg.app.services;

import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.cg.app.dao.CapStoreDao;

import com.cg.app.dao.ProductDao;
import com.cg.app.model.Product;
import com.cg.app.model.PromoGenerator;
@Service
@Transactional
@CrossOrigin(origins="http://localhost:4200")
public class CapStoreServiceImpl implements CapStoreService {
@Autowired private CapStoreDao dao;

@Autowired private ProductDao dao2;
	@Transactional
	public void generatePromo(PromoGenerator promo) {
		dao.save(promo);
			}
	public void createPromo() {
		char[] chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890".toCharArray();
        StringBuilder sb = new StringBuilder();
        Random random = new SecureRandom();
        for (int i = 0; i < 8; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        String a = sb.toString();
        System.out.println(a);
        PromoGenerator cap1=new PromoGenerator();
          	 cap1.setPromocode(a);
             cap1.setDescription("50% of on all TOP BRANDS");
             cap1.setAmount(50d);
          LocalDateTime ld=LocalDateTime.now();
          LocalDateTime nd = ld.plusMonths(2);
         
          String expdate = nd.format(DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss"));
          cap1.setDate(expdate);
          System.out.println(expdate);
             generatePromo(cap1);	
	}
	@Override
	@Transactional
	public List<PromoGenerator> getPromos()
	{
		List<PromoGenerator> clist = dao.findAll();
		return clist;
	}
	
	
	
	










	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		List<Product> plist = dao2.findAll();
		System.out.println(plist);
		return plist;
	}





	@Override
	public void createProduct(Product p) {
		// TODO Auto-generated method stub
		dao2.save(p);
		
	}

	

	
}