package com.cg.app.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.web.bind.annotation.CrossOrigin;

@Entity
@Table(name="promos")
@XmlRootElement
@CrossOrigin(origins="http://localhost:4200")
public class PromoGenerator implements Serializable {
	@Id
	@Column(name="promocode")
	private String promocode;
	@Column(name="description")
	private String description;
		@Column(name="amount")
		private Double amount;
		@Column(name="expdate")
	private String expdate;
	public void setPromocode(String promocode) {
		this.promocode = promocode;
	}
	public String getPromocode() {
		return promocode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getDate() {
		return expdate;
	}	public void setDate(String expdate) {
		this.expdate = expdate;
	}
	


}
