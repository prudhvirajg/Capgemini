package com.cg.app.model;

import javax.persistence.*;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.web.bind.annotation.CrossOrigin;

@Entity
@Table(name="product1")
@XmlRootElement
@CrossOrigin(origins="http://localhost:4200")
public class Product {
	@Id
	@Column(name="productid")
	private Integer productid;
	@Column(name="productdetails")
	private String productdetails;
	@Column(name="price")
	private Double price;
	public Integer getProductid() {
		return productid;
	}

	public void setProductid(Integer productid) {
		this.productid = productid;
	}
	public String getProductdetails() {
		return productdetails;
	}
	public void setProductdetails(String productdetails) {
		this.productdetails = productdetails;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	}
