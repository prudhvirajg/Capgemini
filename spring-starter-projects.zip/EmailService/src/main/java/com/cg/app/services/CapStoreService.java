package com.cg.app.services;
import java.util.List;
import com.cg.app.model.Product;
import com.cg.app.model.PromoGenerator;
public interface CapStoreService {
 void generatePromo( PromoGenerator promo);
	void createPromo();
	List<PromoGenerator> getPromos();
	void createProduct(Product p);
	List<Product> getProducts();
}
