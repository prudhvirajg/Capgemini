package com.cg.account.services;

import java.util.List;

import com.cg.account.entities.Account;

public interface AccountService {
	void create(Account ac);
	Account search(Integer acno);
	void delete(Integer acno);
	Account addMoney(Account ac,double amount);
    String transferMoney(Account ac1,Account ac2,double amount);
    Account Withdraw(Account ac,double amount);
    List<Account> getAllAccount();
    Account Updatename(Account ac,String name);
	Account Updatemobile(Account ac,String mobileno);
}
