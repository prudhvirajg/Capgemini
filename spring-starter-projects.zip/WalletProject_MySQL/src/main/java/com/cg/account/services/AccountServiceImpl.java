package com.cg.account.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.account.exceptions.ApplicationException;
import com.cg.account.dao.AccountDao;
import com.cg.account.entities.Account;
@Service
public class AccountServiceImpl implements AccountService {
	@Autowired private AccountDao dao;
	@Transactional
	public void create(Account ac) {
		// TODO Auto-generated method stub
		if(dao.existsById(ac.getAccno())) {
			throw new ApplicationException("Record already exists!");
		}
     dao.save(ac);
	}
	@Transactional
	public Account search(Integer acno) {
		// TODO Auto-generated method stub
		Optional<Account> temp = dao.findById(acno);
		if(!temp.isPresent()) {
			throw new ApplicationException("Unable to fetch Account "+acno);
		}
		return dao.findById(acno).get();
	}
	@Transactional
	public void delete(Integer acno) {
		// TODO Auto-generated method stub
		if(!dao.existsById(acno)) {
			throw new ApplicationException("Unable to delete, record not found!");
		}
        dao.deleteById(acno);
	}
	@Transactional
	public Account addMoney(Account ac, double amount) {
		// TODO Auto-generated method stub
		if(!dao.existsById(ac.getAccno())) {
			throw new ApplicationException("Account does not exists!"); 
		}
        Double newbal=ac.getBalance()+amount;
        ac.setBalance(newbal);
		return dao.save(ac);
		}
	@Transactional
	public String transferMoney(Account ac1,Account ac2, double amount) {
		// TODO Auto-generated method stub
		if(!dao.existsById(ac1.getAccno())) {
			throw new ApplicationException("Account1 does not exists!"); 
		}
		if(!dao.existsById(ac2.getAccno())) {
			throw new ApplicationException("Account2 does not exists!"); 
		}
		if(amount>ac1.getBalance()) {
			throw new ApplicationException("insufficient funds"); 
		}
		String ok="transfered sucessfully";
		double bal1=ac1.getBalance()-amount;
		double bal2=ac2.getBalance()+amount;
		ac1.setBalance(bal1);
		ac2.setBalance(bal2);
		dao.save(ac1);
		dao.save(ac2);
		return ok;
		}
	@Transactional
	public Account Withdraw(Account ac, double amount) {
		// TODO Auto-generated method stub
		if(!dao.existsById(ac.getAccno())) {
			throw new ApplicationException("Account does not exists!"); 
		}
		if(amount>ac.getBalance()) {
			throw new ApplicationException("insufficient funds"); 
		}
	        Double newbal=ac.getBalance()-amount;
	       
	        ac.setBalance(newbal);
			return dao.save(ac);
		}
	@Transactional
	public List<Account> getAllAccount() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public Account Updatename(Account ac, String name) {
		// TODO Auto-generated method stub
		if(!dao.existsById(ac.getAccno())) {
			throw new ApplicationException("Account does not exists!"); 
		}
		ac.setCustomername(name);
		return dao.save(ac);
	}
	@Override
	public Account Updatemobile(Account ac, String mobileno) {
		// TODO Auto-generated method stub
		if(!dao.existsById(ac.getAccno())) {
			throw new ApplicationException("Account does not exists!"); 
		}
		ac.setMobileno(mobileno);
		return dao.save(ac);
	}
	}
