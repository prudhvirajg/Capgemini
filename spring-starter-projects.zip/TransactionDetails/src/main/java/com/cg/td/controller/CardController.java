package com.cg.td.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.td.entities.Card;
import com.cg.td.service.CardService;

@RestController
@CrossOrigin("http://localhost:4200")
@RequestMapping("/card")
public class CardController {
	@Autowired
	private CardService service;
	
	@PostMapping(value = "/create", consumes = { "application/json","application/xml"})
	public ResponseEntity<String> create(@RequestBody Card c) {
		System.out.println("Create");
		service.create(c);
		return new ResponseEntity<String>("card saved successfully", HttpStatus.CREATED);
}
}
