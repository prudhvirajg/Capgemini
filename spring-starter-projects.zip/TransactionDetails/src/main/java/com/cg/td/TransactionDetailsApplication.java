package com.cg.td;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TransactionDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TransactionDetailsApplication.class, args);
	}

}
