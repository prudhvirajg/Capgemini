package com.cg.td.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.td.entities.Card;
@Repository
public interface CardDao extends JpaRepository<Card, Integer> {

}
