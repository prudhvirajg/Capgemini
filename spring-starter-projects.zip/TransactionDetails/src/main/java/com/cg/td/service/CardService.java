package com.cg.td.service;

import com.cg.td.entities.Card;

public interface CardService {
	public void create(Card c);
}
