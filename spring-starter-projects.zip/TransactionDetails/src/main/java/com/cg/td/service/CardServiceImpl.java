package com.cg.td.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cg.td.entities.Card;
import com.cg.td.repository.CardDao;
@Service
public class CardServiceImpl implements CardService {
@Autowired CardDao rep;
	
	
	@Transactional
	public void create(Card c) {
		rep.save(c);
		
	}

}
