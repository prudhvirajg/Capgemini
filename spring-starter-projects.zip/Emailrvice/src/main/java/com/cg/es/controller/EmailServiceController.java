package com.cg.es.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class EmailServiceController {

	
	
	@PostMapping(value = "/send/{email}")
	public ResponseEntity<String> create(@RequestParam String email) {
		
		
		return new ResponseEntity<String>("Mail has been sent", HttpStatus.CREATED);
}
}
